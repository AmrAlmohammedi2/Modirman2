package com.managerman.app

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

private val Navy = Color(0xFF10243A)
private val Teal = Color(0xFF00A896)
private val Canvas = Color(0xFFF3F6F9)
private val Ink = Color(0xFF182B3A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ManagerManApp(this) }
    }
}

data class RouterProfile(val name: String, val host: String, val port: Int, val user: String, val pass: String)
data class HotspotUser(val name: String, val profile: String, val comment: String)

class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences("managerman_local", Context.MODE_PRIVATE)
    fun saveRouter(r: RouterProfile) {
        val arr = JSONArray(prefs.getString("routers", "[]"))
        val obj = JSONObject().put("name",r.name).put("host",r.host).put("port",r.port)
            .put("user",r.user).put("pass",r.pass)
        var replaced = false
        for (i in 0 until arr.length()) if (arr.getJSONObject(i).optString("host") == r.host) {
            arr.put(i,obj); replaced = true; break
        }
        if (!replaced) arr.put(obj)
        prefs.edit().putString("routers",arr.toString()).apply()
    }
    fun routers(): List<RouterProfile> {
        val a = JSONArray(prefs.getString("routers","[]"))
        return (0 until a.length()).map { val o=a.getJSONObject(it); RouterProfile(o.optString("name"),o.optString("host"),o.optInt("port",8728),o.optString("user"),o.optString("pass")) }
    }
    fun cacheUsers(host: String, users: List<HotspotUser>) {
        val a = JSONArray()
        users.forEach { a.put(JSONObject().put("name",it.name).put("profile",it.profile).put("comment",it.comment)) }
        prefs.edit().putString("users_$host",a.toString()).apply()
    }
    fun cachedUsers(host: String): List<HotspotUser> {
        val a=JSONArray(prefs.getString("users_$host","[]"))
        return (0 until a.length()).map { val o=a.getJSONObject(it); HotspotUser(o.optString("name"),o.optString("profile"),o.optString("comment")) }
    }
}

/** Minimal RouterOS sentence client. Uses legacy API login supported by RouterOS 6/7. */
class RouterOsApi(private val router: RouterProfile) {
    private var socket: java.net.Socket? = null
    private var input: java.io.InputStream? = null
    private var output: java.io.OutputStream? = null

    private fun writeLen(out: java.io.OutputStream, n: Int) {
        when {
            n < 0x80 -> out.write(n)
            n < 0x4000 -> { out.write((n shr 8) or 0x80); out.write(n and 0xff) }
            n < 0x200000 -> { out.write((n shr 16) or 0xC0); out.write((n shr 8) and 0xff); out.write(n and 0xff) }
            n < 0x10000000 -> { out.write((n shr 24) or 0xE0); out.write((n shr 16) and 0xff); out.write((n shr 8) and 0xff); out.write(n and 0xff) }
            else -> { out.write(0xF0); out.write((n shr 24) and 0xff); out.write((n shr 16) and 0xff); out.write((n shr 8) and 0xff); out.write(n and 0xff) }
        }
    }
    private fun readLen(inp: java.io.InputStream): Int {
        val c=inp.read(); if(c<0) return -1
        return when {
            c and 0x80 == 0 -> c
            c and 0xC0 == 0x80 -> ((c and 0x3f) shl 8) or inp.read()
            c and 0xE0 == 0xC0 -> ((c and 0x1f) shl 16) or (inp.read() shl 8) or inp.read()
            c and 0xF0 == 0xE0 -> ((c and 0x0f) shl 24) or (inp.read() shl 16) or (inp.read() shl 8) or inp.read()
            else -> (inp.read() shl 24) or (inp.read() shl 16) or (inp.read() shl 8) or inp.read()
        }
    }
    private fun send(vararg words: String) {
        val out=output ?: error("Not connected")
        words.forEach { val b=it.toByteArray(Charsets.UTF_8); writeLen(out,b.size); out.write(b) }
        out.write(0); out.flush()
    }
    private fun readSentence(): List<String> {
        val inp=input ?: error("Not connected")
        val result=mutableListOf<String>()
        while(true) { val n=readLen(inp); if(n<0) error("Connection closed"); if(n==0) break
            val b=ByteArray(n); var off=0
            while(off<n) { val got=inp.read(b,off,n-off); if(got<0) error("Connection closed"); off+=got }
            result.add(String(b,Charsets.UTF_8))
        }
        return result
    }
    private fun connect() {
        socket=java.net.Socket().apply { connect(java.net.InetSocketAddress(router.host,router.port),7000); soTimeout=9000 }
        input=socket!!.getInputStream(); output=socket!!.getOutputStream()
        send("/login", "=name=${router.user}", "=password=${router.pass}")
        val response=readSentence()
        // Older RouterOS challenge-response compatibility (the challenge may accompany !done).
        val challenge=response.firstOrNull { it.startsWith("=ret=") }?.substringAfter("=ret=")
        if(challenge != null) {
            val bytes=challenge.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
            val md=java.security.MessageDigest.getInstance("MD5")
            md.update(0.toByte()); md.update(router.pass.toByteArray()); val hash=md.digest(bytes).joinToString("") { "%02x".format(it) }
            send("/login","=name=${router.user}","=response=00$hash")
            val second=readSentence()
            if(second.firstOrNull() != "!done") error(second.joinToString(" "))
        } else if(response.firstOrNull() != "!done") error(response.joinToString(" "))
    }
    private fun command(path: String, vararg args: String): List<Map<String,String>> {
        send(path,*args)
        val rows=mutableListOf<Map<String,String>>()
        while(true) {
            val sentence=readSentence()
            when(sentence.firstOrNull()) {
                "!re" -> {
                    val row=linkedMapOf<String,String>()
                    sentence.drop(1).forEach { if(it.startsWith("=")) { val p=it.indexOf('=',1); if(p>0) row[it.substring(1,p)]=it.substring(p+1) } }
                    rows.add(row)
                }
                "!done" -> return rows
                "!trap" -> error(sentence.joinToString(" "))
            }
        }
    }
    fun users(): List<HotspotUser> {
        connect()
        return try { command("/ip/hotspot/user/print").map { HotspotUser(it["name"] ?: "",it["profile"] ?: "default",it["comment"] ?: "") } }
        finally { close() }
    }
    fun activeCount(): Int {
        connect()
        return try { command("/ip/hotspot/active/print").size } finally { close() }
    }
    fun addHotspotUser(name: String, password: String, profile: String) {
        connect()
        try { command("/ip/hotspot/user/add","=name=$name","=password=$password","=profile=$profile") } finally { close() }
    }
    fun removeHotspotUser(name: String) {
        connect()
        try {
            val row=command("/ip/hotspot/user/print","?name=$name").firstOrNull() ?: error("المستخدم غير موجود")
            val id=row[".id"] ?: error("لم يتم استلام معرّف المستخدم")
            command("/ip/hotspot/user/remove","=.id=$id")
        } finally { close() }
    }
    private fun close() { try { socket?.close() } catch (_:Exception) {}; socket=null; input=null; output=null }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManagerManApp(context: Context) {
    val store=remember { LocalStore(context) }
    val scope= rememberCoroutineScope()
    var tab by remember { mutableStateOf(0) }
    var routers by remember { mutableStateOf(store.routers()) }
    var selected by remember { mutableStateOf<RouterProfile?>(routers.firstOrNull()) }
    var users by remember { mutableStateOf(selected?.let { store.cachedUsers(it.host) } ?: emptyList()) }
    var active by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("وضع محلي • لم يتم الاتصال") }
    var busy by remember { mutableStateOf(false) }
    var showRouter by remember { mutableStateOf(false) }
    var showUser by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var routerName by remember { mutableStateOf("") }
    var host by remember { mutableStateOf("") }
    var port by remember { mutableStateOf("8728") }
    var apiUser by remember { mutableStateOf("admin") }
    var apiPass by remember { mutableStateOf("") }
    var newName by remember { mutableStateOf("") }
    var newPass by remember { mutableStateOf("") }
    var newProfile by remember { mutableStateOf("default") }

    fun refresh() {
        val r=selected ?: run { status="أضف راوتراً أولاً"; return }
        busy=true; status="جارٍ الاتصال بالراوتر…"
        scope.launch {
            try {
                val result=withContext(Dispatchers.IO) { val api=RouterOsApi(r); val u=api.users(); val a=api.activeCount(); Pair(u,a) }
                users=result.first; active=result.second; store.cacheUsers(r.host,users)
                status="متصل • تم تحديث البيانات"
            } catch(e:Exception) {
                users=store.cachedUsers(r.host)
                status="تعذر الاتصال: ${e.message ?: "خطأ غير معروف"} • البيانات المحلية معروضة"
            } finally { busy=false }
        }
    }
    MaterialTheme(colorScheme = lightColorScheme(primary=Teal, secondary=Navy, background=Canvas, surface=Color.White)) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Column { Text("مديرمان",fontWeight=FontWeight.Bold,color=Color.White,fontSize=21.sp); Text("MANAGERMAN  •  MIKROTIK",fontSize=10.sp,color=Color(0xFFB9D5D7),letterSpacing=1.5.sp) } },
                    actions = { IconButton(onClick={refresh()}) { Icon(Icons.Default.Refresh,null,tint=Color.White) } },
                    colors=TopAppBarDefaults.topAppBarColors(containerColor=Navy)
                )
            },
            bottomBar = {
                NavigationBar(containerColor=Color.White) {
                    listOf("الرئيسية","المستخدمون","الراوترات","الإعدادات").forEachIndexed { i,label ->
                        NavigationBarItem(selected=tab==i,onClick={tab=i},icon={
                            Icon(when(i){0->Icons.Default.Dashboard;1->Icons.Default.People;2->Icons.Default.Router;else->Icons.Default.Settings},null)
                        },label={Text(label,fontSize=11.sp)})
                    }
                }
            },
            floatingActionButton = {
                if(tab==1 || tab==2) FloatingActionButton(onClick={if(tab==1) showUser=true else showRouter=true},containerColor=Teal,contentColor=Color.White) {
                    Icon(Icons.Default.Add,null)
                }
            },
            containerColor=Canvas
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal=16.dp)) {
                Spacer(Modifier.height(12.dp))
                when(tab) {
                    0 -> {
                        Text("ملخص الشبكة",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink)
                        Text(status,fontSize=12.sp,color=Color.Gray)
                        Spacer(Modifier.height(14.dp))
                        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                            StatCard("المستخدمون","${users.size}",Icons.Default.People,Modifier.weight(1f))
                            StatCard("النشطون","$active",Icons.Default.Wifi,Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                            StatCard("الراوترات","${routers.size}",Icons.Default.Router,Modifier.weight(1f))
                            StatCard("حالة الاتصال",if(status.startsWith("متصل")) "متصل" else "محلي",Icons.Default.CloudDone,Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(18.dp))
                        Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Navy),modifier=Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(18.dp)) {
                                Text("الراوتر الحالي",color=Color(0xFFB9D5D7),fontSize=12.sp)
                                Text(selected?.name ?: "لم تتم إضافة راوتر",color=Color.White,fontSize=19.sp,fontWeight=FontWeight.Bold)
                                Text(selected?.host ?: "أضف عنوان الراوتر للبدء",color=Color.LightGray,fontSize=13.sp)
                                Spacer(Modifier.height(12.dp))
                                Button(onClick={refresh()},enabled=!busy,colors=ButtonDefaults.buttonColors(containerColor=Teal)) {
                                    if(busy) CircularProgressIndicator(Modifier.size(16.dp),strokeWidth=2.dp,color=Color.White) else Icon(Icons.Default.Sync,null)
                                    Spacer(Modifier.width(8.dp)); Text("مزامنة محلية مع الراوتر")
                                }
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                        Text("اختصارات الإدارة",fontWeight=FontWeight.Bold,color=Ink)
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            QuickAction("المستخدمون",Icons.Default.People,Modifier.weight(1f)){tab=1}
                            QuickAction("إضافة راوتر",Icons.Default.Router,Modifier.weight(1f)){showRouter=true}
                            QuickAction("إنشاء مستخدم",Icons.Default.PersonAdd,Modifier.weight(1f)){showUser=true}
                        }
                    }
                    1 -> {
                        Text("إدارة المستخدمين",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink)
                        OutlinedTextField(search,{search=it},Modifier.fillMaxWidth(),placeholder={Text("ابحث باسم المستخدم")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true)
                        Text("${users.size} مستخدم محفوظ محلياً",fontSize=12.sp,color=Color.Gray)
                        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(vertical=10.dp)) {
                            items(users.filter { it.name.contains(search,true) }) { u ->
                                Card(colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(14.dp)) {
                                    Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                                        Box(Modifier.size(38.dp).background(Color(0xFFE1F5F2),RoundedCornerShape(12.dp)),contentAlignment=Alignment.Center) { Icon(Icons.Default.Person,color=Teal,null) }
                                        Spacer(Modifier.width(10.dp))
                                        Column(Modifier.weight(1f)) { Text(u.name,fontWeight=FontWeight.SemiBold,color=Ink); Text("الباقة: ${u.profile}",fontSize=12.sp,color=Color.Gray) }
                                        IconButton(onClick={
                                            val r=selected ?: return@IconButton
                                            scope.launch { try { withContext(Dispatchers.IO){RouterOsApi(r).removeHotspotUser(u.name)}; users=users.filterNot{it.name==u.name}; store.cacheUsers(r.host,users); status="تم حذف ${u.name}" } catch(e:Exception){status=e.message ?: "تعذر الحذف"} }
                                        }) { Icon(Icons.Default.Delete,color=Color(0xFFD45B5B),contentDescription="حذف") }
                                    }
                                }
                            }
                        }
                    }
                    2 -> {
                        Text("أجهزة MikroTik",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink)
                        Text("تُحفظ إعدادات الراوتر على هذا الهاتف",fontSize=12.sp,color=Color.Gray)
                        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(vertical=12.dp)) {
                            items(routers) { r ->
                                Card(colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(14.dp)) {
                                    Row(Modifier.fillMaxWidth().clickable { selected=r; users=store.cachedUsers(r.host); tab=0 }.padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
                                        Icon(Icons.Default.Router,color=Teal,modifier=Modifier.size(32.dp),contentDescription=null)
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f)) { Text(r.name,fontWeight=FontWeight.Bold); Text("${r.host}:${r.port}",fontSize=12.sp,color=Color.Gray) }
                                        RadioButton(selected=selected?.host==r.host,onClick={selected=r; users=store.cachedUsers(r.host)})
                                    }
                                }
                            }
                        }
                        if(routers.isEmpty()) EmptyHint("لا توجد راوترات مضافة بعد")
                    }
                    else -> {
                        Text("الإعدادات",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Ink)
                        Card(colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(16.dp)) {
                            Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                                Text("طريقة التشغيل",fontWeight=FontWeight.Bold)
                                Text("محلي عبر Wi-Fi / LAN دون الحاجة إلى الإنترنت.",color=Color.Gray)
                                Divider()
                                Text("المزامنة السحابية",fontWeight=FontWeight.Bold)
                                Text("غير مفعّلة في هذا الإصدار. ستضاف كخيار مستقل بموافقة المستخدم.",color=Color.Gray)
                                Divider()
                                Text("الإصدار 0.1.0 • RouterOS 6 / 7",color=Teal,fontWeight=FontWeight.SemiBold)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
        }
        if(showRouter) AlertDialog(
            onDismissRequest={showRouter=false},title={Text("إضافة راوتر MikroTik")},
            text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(routerName,{routerName=it},label={Text("اسم الراوتر")},singleLine=true)
                OutlinedTextField(host,{host=it},label={Text("IP أو اسم المضيف")},singleLine=true)
                OutlinedTextField(port,{port=it},label={Text("منفذ API")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true)
                OutlinedTextField(apiUser,{apiUser=it},label={Text("اسم المستخدم")},singleLine=true)
                OutlinedTextField(apiPass,{apiPass=it},label={Text("كلمة المرور")},visualTransformation=PasswordVisualTransformation(),singleLine=true)
            }},
            confirmButton={TextButton(onClick={
                val r=RouterProfile(routerName.ifBlank{"MikroTik"},host.trim(),port.toIntOrNull()?:8728,apiUser,apiPass)
                if(r.host.isNotBlank()){store.saveRouter(r);routers=store.routers();selected=r;showRouter=false;status="تم حفظ الراوتر محلياً"}
            }){Text("حفظ")}},
            dismissButton={TextButton(onClick={showRouter=false}){Text("إلغاء")}}
        )
        if(showUser) AlertDialog(
            onDismissRequest={showUser=false},title={Text("إنشاء مستخدم Hotspot")},
            text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(newName,{newName=it},label={Text("اسم المستخدم")},singleLine=true)
                OutlinedTextField(newPass,{newPass=it},label={Text("كلمة المرور")},singleLine=true)
                OutlinedTextField(newProfile,{newProfile=it},label={Text("اسم الباقة / Profile")},singleLine=true)
                Text("يتطلب اتصالاً مباشراً بالراوتر لتنفيذ الإضافة.",fontSize=11.sp,color=Color.Gray)
            }},
            confirmButton={TextButton(onClick={
                val r=selected
                if(r!=null && newName.isNotBlank()) scope.launch {
                    busy=true
                    try { withContext(Dispatchers.IO){RouterOsApi(r).addHotspotUser(newName,newPass,newProfile)}; status="تم إنشاء المستخدم"; refresh() }
                    catch(e:Exception){status=e.message ?: "فشل إنشاء المستخدم"}
                    finally {busy=false}
                } else status="اختر راوتراً أولاً"
                showUser=false; newName=""; newPass=""
            }){Text("إنشاء")}},
            dismissButton={TextButton(onClick={showUser=false}){Text("إلغاء")}}
        )
    }
}

@Composable
fun StatCard(title:String,value:String,icon:androidx.compose.ui.graphics.vector.ImageVector,modifier:Modifier=Modifier) {
    Card(modifier,shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
        Column(Modifier.padding(14.dp)) {
            Icon(icon,tint=Teal,contentDescription=null)
            Spacer(Modifier.height(8.dp))
            Text(value,fontSize=23.sp,fontWeight=FontWeight.Bold,color=Ink)
            Text(title,fontSize=12.sp,color=Color.Gray)
        }
    }
}
@Composable
fun QuickAction(label:String,icon:androidx.compose.ui.graphics.vector.ImageVector,modifier:Modifier=Modifier,onClick:()->Unit) {
    Card(modifier.clickable(onClick=onClick),shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
        Column(Modifier.fillMaxWidth().padding(vertical=14.dp),horizontalAlignment=Alignment.CenterHorizontally) {
            Icon(icon,tint=Teal,contentDescription=null)
            Spacer(Modifier.height(5.dp)); Text(label,fontSize=10.sp,color=Ink)
        }
    }
}
@Composable
fun EmptyHint(text:String) {
    Box(Modifier.fillMaxWidth().padding(25.dp),contentAlignment=Alignment.Center) { Text(text,color=Color.Gray) }
}
